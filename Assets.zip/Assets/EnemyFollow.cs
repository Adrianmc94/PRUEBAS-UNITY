using UnityEngine;
using UnityEngine.AI; // Esto es vital para usar el NavMesh

public class EnemyFollow : MonoBehaviour
{
    public Transform player; // Aquí arrastraremos al jugador en el Inspector
    private NavMeshAgent agent;

    void Start()
    {
        // Buscamos el componente NavMeshAgent que pusimos al enemigo
        agent = GetComponent<NavMeshAgent>();
    }

    void Update()
    {
        // Le decimos al agente que su destino es la posición del jugador
        if (player != null)
        {
            agent.SetDestination(player.position);
        }
    }
}