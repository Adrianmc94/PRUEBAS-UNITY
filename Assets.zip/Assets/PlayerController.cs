using UnityEngine;
using UnityEngine.InputSystem; 
using TMPro; 

public class PlayerController : MonoBehaviour
{
    public float speed = 10; 
    public TextMeshProUGUI countText;
    public GameObject winTextObject;

    private Rigidbody rb;
    private int count;
    private float movementX;
    private float movementY;

    void Start()
    {
        rb = GetComponent<Rigidbody>(); 
        count = 0; 
        SetCountText();
        winTextObject.SetActive(false); 
    }

    void OnMove(InputValue movementValue)
    {
        Vector2 movementVector = movementValue.Get<Vector2>();
        movementX = movementVector.x;
        movementY = movementVector.y;
    }

    void FixedUpdate()
    {
        Vector3 movement = new Vector3(movementX, 0.0f, movementY);
        rb.AddForce(movement * speed);
    }

    // ESTO ES PARA LOS PREMIOS (TRIGGERS)
    void OnTriggerEnter(Collider other) 
    {
        if (other.gameObject.CompareTag("PickUp")) 
        {
            other.gameObject.SetActive(false); 
            count = count + 1; 
            SetCountText();
        }
    }

    // --- NUEVO: ESTO ES PARA EL ENEMIGO (COLISIONES SÓLIDAS) ---
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemigo"))
        {
            // Desactivamos al jugador (muerte)
            gameObject.SetActive(false);
            
            // Cambiamos el texto para avisar del Game Over
            countText.text = "¡GAME OVER!";
            winTextObject.SetActive(true);
            winTextObject.GetComponent<TextMeshProUGUI>().text = "TE HA PILLADO";
        }
    }
    // ----------------------------------------------------------

    void SetCountText()
    {
        countText.text = "Count: " + count.ToString();
        if (count >= 12) 
        {
            winTextObject.SetActive(true);
            winTextObject.GetComponent<TextMeshProUGUI>().text = "¡HAS GANADO!";
        }
    }
}