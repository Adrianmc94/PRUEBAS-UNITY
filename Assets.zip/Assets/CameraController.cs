using UnityEngine;

public class CameraController : MonoBehaviour
{
    public GameObject player; // Arrastraremos al Player aquí en el Inspector
    private Vector3 offset;   // La distancia que hay entre la cámara y la bola

    void Start()
    {
        // Calculamos la distancia inicial (Posición Cámara - Posición Jugador)
        offset = transform.position - player.transform.position;
    }

    // LateUpdate se ejecuta después de que el Player se haya movido
    void LateUpdate()
    {
        // Mueve la cámara a la nueva posición del jugador, manteniendo la distancia
        transform.position = player.transform.position + offset;
    }
}