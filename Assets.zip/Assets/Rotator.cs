using UnityEngine;

public class Rotator : MonoBehaviour
{
    // Update se ejecuta en cada fotograma
    void Update()
    {
        // Rota el objeto en diferentes ejes multiplicando por el tiempo para que sea fluido
        transform.Rotate(new Vector3(15, 30, 45) * Time.deltaTime);
    }
}